

The following artifacts are included in this package:
    MobileBackend s1_otbi v1.0
    API s1_otbiccs v.1.0 => APIImplementation s1_otbiccs v17.4.3
    UserRealm Default v1.0
